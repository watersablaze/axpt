const TYPES = ['address', 'bytes32', 'uint256'];

module.exports = { TYPES };
