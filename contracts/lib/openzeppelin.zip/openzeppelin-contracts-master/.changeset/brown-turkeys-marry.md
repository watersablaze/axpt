---
'openzeppelin-solidity': minor
---

`ER6909TokenSupply`: Add an extension of ERC6909 which tracks total supply for each token id.
