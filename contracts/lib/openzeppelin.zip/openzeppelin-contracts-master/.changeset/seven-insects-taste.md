---
'openzeppelin-solidity': patch
---

`ERC7579Utils`: Add ABI decoding checks on calldata bounds within `decodeBatch`
