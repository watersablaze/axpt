---
'openzeppelin-solidity': minor
---

`EnumerableSet`: Add `Bytes32x2Set` that handles (ordered) pairs of bytes32.
