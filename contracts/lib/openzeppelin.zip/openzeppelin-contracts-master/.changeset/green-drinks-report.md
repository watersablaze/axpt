---
"openzeppelin-solidity": minor
---

`Pausable`: Stop explicitly setting `paused` to `false` during construction.
