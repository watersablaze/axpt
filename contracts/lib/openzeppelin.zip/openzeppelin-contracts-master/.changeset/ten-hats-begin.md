---
'openzeppelin-solidity': minor
---

`ERC6909`: Add a standard implementation of ERC6909.
