---
'openzeppelin-solidity': patch
---

`ERC4626`: Use the `asset` getter in `totalAssets`, `_deposit` and `_withdraw`.
