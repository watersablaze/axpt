---
'openzeppelin-solidity': minor
---

`IERC6909`: Add the interface for ERC-6909.
