---
'openzeppelin-solidity': minor
---

`GovernorSequentialProposalId`: Adds a `Governor` extension that sequentially numbers proposal ids instead of using the hash.
