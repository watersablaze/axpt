---
'openzeppelin-solidity': minor
---

`Address`: bubble up revert data on `sendValue` failed call
