---
'openzeppelin-solidity': minor
---

`ERC2771Forwarder`: Expose the `_isTrustedByTarget` internal function to check whether a target trusts the forwarder.
