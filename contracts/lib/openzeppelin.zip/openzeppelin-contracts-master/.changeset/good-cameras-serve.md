---
"openzeppelin-solidity": minor
---

`Calldata`: Library with `emptyBytes` and `emptyString` functions to generate empty `bytes` and `string` calldata types.
