---
'openzeppelin-solidity': minor
---

`ERC6909ContentURI`: Add an extension of ERC6909 which adds content URI functionality.
