---
'openzeppelin-solidity': minor
---

`ERC6909Metadata`: Add an extension of ERC6909 which adds metadata functionality.
