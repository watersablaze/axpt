---
'openzeppelin-solidity': minor
---

`IGovernor`: Add the `getProposalId` function to the governor interface.
