---
'openzeppelin-solidity': minor
---

`Hashes`: Expose `efficientKeccak256` for hashing non-commutative pairs of bytes32 without allocating extra memory.
